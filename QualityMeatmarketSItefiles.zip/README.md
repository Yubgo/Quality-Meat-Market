# ButcherBox - Premium Meat Delivery Website

A modern, animated website for ButcherBox, a local butcher business specializing in premium meat delivery subscriptions.

## Features

### 🎨 Design & Animations

#### Navigation
- Fixed navigation bar with transparency that becomes solid on scroll
- Water drop animations on hover over menu items
- Drop shadow effects on navigation links
- Smooth color transitions

#### Hero Section
- **Floating Logo Animation**: The ButcherBox logo floats up and down continuously
- **Particle Animation**: 50 green particles that move upward across a gradient background
- **Interactive Particles**: Particles slow down when the mouse stops moving and speed up when moving
- **Gradient Background**: White to green gradient (white → green-50 → green-100)
- **Animated CTA Button**: 
  - Semi-transparent "Prefer to call?" button
  - Hover animation that fades text from "Prefer to call?" to the phone number "855-981-8568"
  - Color change animation on hover
  - Scale transform effect
- **Stats Counter**: Three animated statistics that fade in from bottom

#### Product Showcase
- 9 premium products displayed in a responsive grid
- Scroll-triggered animations - products slide in from bottom when visible
- Staggered animation delays for each product card
- Hover effects with shadow and translation
- Icon bounce animation on card hover
- Gradient backgrounds on each card

#### Standards Section
- Carousel with 4 standards/values
- Auto-rotating carousel (4 seconds per slide)
- Smooth slide transitions
- Navigation dots for manual control
- Mobile-friendly grid layout
- Full-width gradient backgrounds

#### How It Works
- 3-step process with numbered circles
- Scroll-triggered animations
- Pulse animation on decorative dots
- Scale and rotate effects on hover
- Benefits grid with checkmark icons
- Staggered fade-in animations

#### Why Choose Us
- 3 reason cards with badges
- Hover effects with shadow and lift
- Comprehensive comparison table
- Responsive table design with horizontal scroll
- Color-coded features

#### Testimonials
- Auto-rotating testimonial carousel (5 seconds)
- 5-star rating display
- Smooth slide transitions
- Founder story section with gradient background
- Navigation dots

#### Footer
- Comprehensive footer with multiple sections
- Animated CTA with bouncing fire emoji
- Social media links with hover effects
- Contact information
- Quick links and support sections

### 🎯 Technical Features

- **React 18** with TypeScript
- **Tailwind CSS** for styling
- **Vite** for fast build and development
- **Responsive Design** - mobile, tablet, and desktop optimized
- **Performance Optimized** - lazy loading and intersection observers
- **SEO Friendly** - semantic HTML structure
- **Accessible** - ARIA labels and keyboard navigation

### 📱 Responsive Breakpoints

- Mobile: < 640px
- Tablet: 640px - 1024px
- Desktop: > 1024px

## Color Palette

- **Primary Green**: #22C55E (green-600)
- **Dark Green**: #16A34A (green-700)
- **Light Green**: #F0FDF4 (green-50)
- **White**: #FFFFFF
- **Black**: #000000
- **Gray Shades**: Various (gray-100 to gray-900)

## Animations List

1. **Float Animation**: Vertical floating motion for logo
2. **Headline Float**: Subtle floating for headlines
3. **Fade In Up**: Bottom-to-top fade for stats
4. **Water Drop**: Falling water drop on nav hover
5. **Particle Movement**: Upward particle flow
6. **Slide In**: Products sliding from bottom
7. **Icon Bounce**: Product icons bouncing on hover
8. **Step Slide In**: How It Works steps animation
9. **Pulse**: Continuous pulsing decorative elements
10. **Benefit Fade**: Left-to-right fade for benefits
11. **Carousel Transitions**: Smooth slide transitions
12. **Card Hover**: Lift and shadow effects
13. **Button Hover**: Scale and color transitions

## Components Structure

```
src/
├── App.tsx                 # Main app component
├── components/
│   ├── Navigation.tsx      # Fixed navigation bar
│   ├── Hero.tsx           # Hero section with particles
│   ├── ProductShowcase.tsx # Product grid
│   ├── Standards.tsx      # Standards carousel
│   ├── HowItWorks.tsx     # Process steps
│   ├── WhyChooseUs.tsx    # Benefits and comparison
│   ├── Testimonials.tsx   # Customer reviews
│   └── Footer.tsx         # Footer with CTA
```

## Getting Started

### Development
```bash
npm install
npm run dev
```

### Production Build
```bash
npm run build
```

The built files will be in the `dist/` directory.

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Performance

- Optimized animations using CSS transforms
- Intersection Observer for scroll animations
- Canvas-based particle system
- Minimal JavaScript bundle
- Tailwind CSS purging for minimal CSS

## Accessibility

- Semantic HTML elements
- ARIA labels on interactive elements
- Keyboard navigation support
- Color contrast compliance
- Screen reader friendly

---

Built with ❤️ for ButcherBox
