import { useState, useEffect } from 'react';

const testimonials = [
  {
    name: 'Keri W.',
    location: 'WV',
    plan: 'Signature - Medium',
    rating: 5,
    text: 'I love that I can receive all of the meat my family consumes right to my doorstep. And even better, they are good quality products that I am feeding my family.',
  },
  {
    name: 'Michael S.',
    location: 'CA',
    plan: 'Essentials',
    rating: 5,
    text: 'The quality is outstanding! Every cut of meat has been tender, flavorful, and exactly what I expected. I\'ll never go back to the grocery store.',
  },
  {
    name: 'Sarah L.',
    location: 'TX',
    plan: 'Signature - Large',
    rating: 5,
    text: 'ButcherBox has made meal planning so much easier. The convenience and quality can\'t be beat. My family loves every meal!',
  },
];

const Testimonials = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % testimonials.length);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <section className="py-20 bg-gradient-to-b from-green-50 to-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl md:text-5xl font-bold text-center text-gray-800 mb-16">
          What Our Members Say
        </h2>

        <div className="relative">
          {/* Testimonial Cards */}
          <div className="relative overflow-hidden rounded-2xl bg-white shadow-2xl" style={{ minHeight: '300px' }}>
            {testimonials.map((testimonial, index) => (
              <div
                key={index}
                className={`absolute inset-0 p-8 md:p-12 transition-all duration-700 ${
                  index === activeIndex
                    ? 'opacity-100 translate-x-0'
                    : index < activeIndex
                    ? 'opacity-0 -translate-x-full'
                    : 'opacity-0 translate-x-full'
                }`}
              >
                {/* Star Rating */}
                <div className="flex justify-center mb-6">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <svg
                      key={i}
                      className="w-8 h-8 text-yellow-400 fill-current"
                      viewBox="0 0 24 24"
                    >
                      <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                    </svg>
                  ))}
                </div>

                {/* Testimonial Text */}
                <blockquote className="text-xl md:text-2xl text-gray-700 text-center mb-8 italic leading-relaxed">
                  "{testimonial.text}"
                </blockquote>

                {/* Author Info */}
                <div className="text-center">
                  <p className="text-lg font-bold text-gray-800">
                    {testimonial.name}, {testimonial.location}
                  </p>
                  <p className="text-green-600 font-semibold">{testimonial.plan}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Navigation Dots */}
          <div className="flex justify-center mt-8 space-x-3">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setActiveIndex(index)}
                className={`w-3 h-3 rounded-full transition-all duration-300 ${
                  index === activeIndex ? 'bg-green-600 w-8' : 'bg-gray-300'
                }`}
                aria-label={`Go to testimonial ${index + 1}`}
              />
            ))}
          </div>
        </div>

        {/* Founder Story Section */}
        <div className="mt-20 bg-gradient-to-r from-green-600 to-green-700 rounded-2xl shadow-2xl overflow-hidden">
          <div className="grid md:grid-cols-2 gap-0">
            <div className="p-8 md:p-12 flex flex-col justify-center text-white">
              <p className="text-green-200 text-sm uppercase tracking-wide mb-2">Seeking a better way</p>
              <h3 className="text-3xl md:text-4xl font-bold mb-4">
                Our founder Mike Salguero's pursuit of healthier meat for all.
              </h3>
              <p className="text-green-100 mb-6 leading-relaxed">
                ButcherBox is on a mission to bring better meat and seafood to every table. This means that all of our meat and seafood is free from antibiotics and added hormones.
              </p>
              <button className="self-start px-6 py-3 bg-white text-green-700 font-semibold rounded-lg hover:bg-green-50 transition-colors duration-300">
                Read Our Story
              </button>
            </div>
            <div className="relative overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1556157382-97eda2d62296?w=800&h=800&fit=crop&q=90&sat=-100" 
                alt="Mike Salguero - Founder" 
                className="w-full h-full object-cover grayscale contrast-125 brightness-110"
                style={{ minHeight: '400px' }}
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
