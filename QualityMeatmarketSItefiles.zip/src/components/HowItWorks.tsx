import { useEffect, useRef, useState } from 'react';

const steps = [
  {
    number: '1',
    title: 'Pick your plan',
    description: 'Find the plan that best fits your needs—choose between Signature or Essentials.',
  },
  {
    number: '2',
    title: 'Build your box',
    description: 'Select your preferred premium cuts that fit your family\'s tastes and needs.',
  },
  {
    number: '3',
    title: 'Get it delivered for free',
    description: 'Receive your box within 1-3 days—shipping\'s always on us.',
  },
];

const benefits = [
  'Flexible Subscription',
  'Skip or Cancel Anytime',
  'Free Shipping',
  '100% Satisfaction Guarantee',
  'Third-Party Certified for Animal Welfare',
  'No Antibiotics Ever',
];

const HowItWorks = () => {
  const [visibleSteps, setVisibleSteps] = useState<Set<number>>(new Set());
  const stepRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const index = stepRefs.current.indexOf(entry.target as HTMLDivElement);
          if (entry.isIntersecting && index !== -1) {
            setVisibleSteps((prev) => new Set([...prev, index]));
          }
        });
      },
      { threshold: 0.2 }
    );

    stepRefs.current.forEach((ref) => {
      if (ref) observer.observe(ref);
    });

    return () => observer.disconnect();
  }, []);

  return (
    <section id="how-it-works" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-4">
          <p className="text-green-600 font-semibold text-lg">Flexible Subscription, Zero Risk</p>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mt-2">How It Works</h2>
        </div>

        {/* Steps */}
        <div className="grid md:grid-cols-3 gap-12 mb-16 mt-12">
          {steps.map((step, index) => (
            <div
              key={index}
              ref={(el) => {
                stepRefs.current[index] = el;
              }}
              className={`text-center step-card ${
                visibleSteps.has(index) ? 'step-visible' : 'step-hidden'
              }`}
              style={{ animationDelay: `${index * 0.2}s` }}
            >
              <div className="relative inline-block mb-6">
                <div className="number-circle w-24 h-24 rounded-full bg-gradient-to-br from-green-500 to-green-700 flex items-center justify-center text-white text-4xl font-bold shadow-lg">
                  {step.number}
                </div>
                <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-green-400 rounded-full pulse-animation"></div>
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-3">{step.title}</h3>
              <p className="text-gray-600 leading-relaxed">{step.description}</p>
            </div>
          ))}
        </div>

        {/* Benefits Grid */}
        <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-2xl p-8 shadow-lg">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {benefits.map((benefit, index) => (
              <div
                key={index}
                className="flex items-center space-x-3 benefit-item"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="flex-shrink-0 w-8 h-8 bg-green-600 rounded-full flex items-center justify-center">
                  <svg
                    className="w-5 h-5 text-white"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <span className="font-semibold text-gray-800">{benefit}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes stepSlideIn {
          from {
            opacity: 0;
            transform: translateY(60px) scale(0.9);
          }
          to {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }

        @keyframes pulse {
          0%, 100% {
            transform: scale(1);
            opacity: 1;
          }
          50% {
            transform: scale(1.2);
            opacity: 0.7;
          }
        }

        @keyframes benefitFade {
          from {
            opacity: 0;
            transform: translateX(-20px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }

        .step-hidden {
          opacity: 0;
          transform: translateY(60px) scale(0.9);
        }

        .step-visible {
          animation: stepSlideIn 0.8s ease-out forwards;
        }

        .pulse-animation {
          animation: pulse 2s ease-in-out infinite;
        }

        .benefit-item {
          animation: benefitFade 0.6s ease-out forwards;
          opacity: 0;
        }

        .number-circle {
          transition: transform 0.3s ease;
        }

        .step-card:hover .number-circle {
          transform: scale(1.1) rotate(5deg);
        }
      `}</style>
    </section>
  );
};

export default HowItWorks;
