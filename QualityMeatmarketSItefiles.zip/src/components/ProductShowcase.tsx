import { useEffect, useRef, useState } from 'react';

const products = [
  {
    name: '100% Grass-Fed, Pasture-Raised Ribeyes',
    category: '100% Grass-Fed, Pasture-Raised',
    image: '/images/steak.jpg',
    isPhoto: true,
  },
  {
    name: '100% Grass-Fed, Pasture-Raised New York Strips',
    category: '100% Grass-Fed, Pasture-Raised',
    image: '/images/steak.jpg',
    isPhoto: true,
  },
  {
    name: 'Organic Free-Range Boneless Skinless Chicken Breasts',
    category: 'Organic, Free-Range',
    image: '/images/chicken.jpg',
    isPhoto: true,
  },
  {
    name: 'Wild-Caught Sockeye Salmon',
    category: 'Wild-Caught',
    image: '/images/seafood.jpg',
    isPhoto: true,
  },
  {
    name: 'Crate-Free Boneless Pork Chops',
    category: 'Crate-Free',
    image: '/images/pork.jpg',
    isPhoto: true,
  },
  {
    name: 'Organic Free-Range Bone-in Chicken Thighs',
    category: 'Organic, Free-Range',
    image: '/images/chicken.jpg',
    isPhoto: true,
  },
  {
    name: '100% Grass-Fed, Pasture-Raised Top Sirloin Steaks',
    category: '100% Grass-Fed, Pasture-Raised',
    image: '/images/steak.jpg',
    isPhoto: true,
  },
  {
    name: 'Applewood Smoked, Crate-Free ButcherBox Bacon',
    category: 'Crate-Free',
    image: '/images/bacon.jpg',
    isPhoto: true,
  },
  {
    name: 'Wild-Caught Sea Scallops',
    category: 'Wild-Caught',
    image: '/images/seafood.jpg',
    isPhoto: true,
  },
];

const ProductShowcase = () => {
  const [visibleItems, setVisibleItems] = useState<Set<number>>(new Set());
  const itemRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const index = itemRefs.current.indexOf(entry.target as HTMLDivElement);
          if (entry.isIntersecting && index !== -1) {
            setVisibleItems((prev) => new Set([...prev, index]));
          }
        });
      },
      { threshold: 0.1 }
    );

    itemRefs.current.forEach((ref) => {
      if (ref) observer.observe(ref);
    });

    return () => observer.disconnect();
  }, []);

  return (
    <section id="products" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl md:text-5xl font-bold text-center text-gray-800 mb-4">
          Discover 100+ premium proteins
        </h2>
        <p className="text-center text-gray-600 mb-12 text-lg">
          From thick-cut steaks to wild-caught seafood
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product, index) => (
            <div
              key={index}
              ref={(el) => {
                itemRefs.current[index] = el;
              }}
              className={`product-card bg-gradient-to-br from-white to-green-50 rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-500 cursor-pointer transform hover:-translate-y-2 ${
                visibleItems.has(index) ? 'slide-in-visible' : 'slide-in-hidden'
              }`}
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {product.isPhoto ? (
                <div className="relative h-48 mb-4 overflow-hidden rounded-lg">
                  <img 
                    src={product.image} 
                    alt={product.name}
                    className="w-full h-full object-cover product-icon"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
                </div>
              ) : (
                <div className="text-6xl mb-4 text-center product-icon">{product.image}</div>
              )}
              <div className="px-6 pb-6">
                <div className="text-sm text-green-600 font-semibold mb-2 text-center">
                  {product.category}
                </div>
                <h3 className="text-lg font-bold text-gray-800 text-center">{product.name}</h3>
              </div>
            </div>
          ))}
        </div>
      </div>

      <style>{`
        @keyframes slideIn {
          from {
            opacity: 0;
            transform: translateY(50px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes iconBounce {
          0%, 100% {
            transform: scale(1);
          }
          50% {
            transform: scale(1.1);
          }
        }

        .slide-in-hidden {
          opacity: 0;
          transform: translateY(50px);
        }

        .slide-in-visible {
          animation: slideIn 0.6s ease-out forwards;
        }

        .product-card:hover .product-icon {
          animation: iconBounce 0.5s ease-in-out;
        }

        .product-card {
          border: 1px solid rgba(34, 197, 94, 0.1);
        }

        .product-card:hover {
          border-color: rgba(34, 197, 94, 0.3);
        }
      `}</style>
    </section>
  );
};

export default ProductShowcase;
