import { useState, useEffect, useRef } from 'react';

const Hero = () => {
  const [mouseMoving, setMouseMoving] = useState(true);
  const [isHovered, setIsHovered] = useState(false);
  const timeoutRef = useRef<number | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const handleMouseMove = () => {
      setMouseMoving(true);
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
      timeoutRef.current = window.setTimeout(() => {
        setMouseMoving(false);
      }, 500);
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  // Particle animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const particles: Array<{
      x: number;
      y: number;
      size: number;
      speedY: number;
      opacity: number;
    }> = [];

    // Create particles
    for (let i = 0; i < 50; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 3 + 1,
        speedY: Math.random() * 0.5 + 0.2,
        opacity: Math.random() * 0.3 + 0.1,
      });
    }

    let animationFrameId: number;
    let slowdown = 1;

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Adjust speed based on mouse movement
      slowdown = mouseMoving ? 1 : 0.2;

      particles.forEach((particle) => {
        ctx.fillStyle = `rgba(34, 197, 94, ${particle.opacity})`;
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
        ctx.fill();

        // Move particle upward
        particle.y -= particle.speedY * slowdown;

        // Reset particle when it goes off screen
        if (particle.y < 0) {
          particle.y = canvas.height;
          particle.x = Math.random() * canvas.width;
        }
      });

      animationFrameId = requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, [mouseMoving]);

  return (
    <section id="home" className="relative min-h-screen overflow-hidden">
      {/* Gradient Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-white via-green-50 to-green-100" />

      {/* Particle Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none"
        style={{ opacity: 0.6 }}
      />

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-4 pt-20">
        {/* Logo with floating animation - 7x bigger */}
        <div className="mb-8 logo-float">
          <img 
            src="https://raw.githubusercontent.com/Yubgo/Quality-Meat-Market/main/Quality%20Meat%20Market/IMAGES/Quality%20Meat%20Market%20logo.png" 
            alt="Quality Meat Market"
            className="w-auto h-[392px] md:h-[560px] lg:h-[672px] drop-shadow-2xl"
          />
        </div>

        {/* Subheadline */}
        <p className="text-xl md:text-2xl text-gray-700 text-center mb-12 max-w-2xl">
          More nutritious than grocery store meat—tested and proven.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-6 items-center">
          <button className="px-8 py-4 bg-green-600 text-white font-semibold rounded-lg shadow-lg hover:bg-green-700 transform hover:scale-105 transition-all duration-300">
            Get Started Today
          </button>

          {/* Call Button with Hover Animation */}
          <button
            className="call-button relative px-8 py-4 bg-white/30 backdrop-blur-sm text-gray-800 font-semibold rounded-lg shadow-lg overflow-hidden transition-all duration-500"
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
          >
            <span
              className={`absolute inset-0 flex items-center justify-center transition-opacity duration-500 ${
                isHovered ? 'opacity-0' : 'opacity-100'
              }`}
            >
              Prefer to call?
            </span>
            <span
              className={`absolute inset-0 flex items-center justify-center transition-opacity duration-500 ${
                isHovered ? 'opacity-100' : 'opacity-0'
              }`}
            >
              855-981-8568
            </span>
            <span className="opacity-0">855-981-8568</span>
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-20 max-w-4xl w-full">
          <div className="text-center fade-in-up">
            <div className="text-4xl font-bold text-green-600 mb-2">400k+</div>
            <div className="text-gray-700">Subscribers</div>
          </div>
          <div className="text-center fade-in-up" style={{ animationDelay: '0.2s' }}>
            <div className="text-4xl font-bold text-green-600 mb-2">1B+</div>
            <div className="text-gray-700">Better Meals Sent</div>
          </div>
          <div className="text-center fade-in-up" style={{ animationDelay: '0.4s' }}>
            <div className="text-4xl font-bold text-green-600 mb-2">70k+</div>
            <div className="text-gray-700">5-Star Reviews</div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes float {
          0%, 100% {
            transform: translateY(0);
          }
          50% {
            transform: translateY(-20px);
          }
        }

        @keyframes headlineFloat {
          0%, 100% {
            transform: translateY(0);
          }
          50% {
            transform: translateY(-10px);
          }
        }

        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .logo-float {
          animation: float 4s ease-in-out infinite;
        }

        .headline-float {
          animation: headlineFloat 5s ease-in-out infinite;
        }

        .fade-in-up {
          animation: fadeInUp 1s ease-out forwards;
          opacity: 0;
        }

        .call-button {
          border: 2px solid rgba(34, 197, 94, 0.3);
        }

        .call-button:hover {
          background: linear-gradient(135deg, rgba(34, 197, 94, 0.2), rgba(16, 185, 129, 0.3));
          border-color: rgba(34, 197, 94, 0.6);
          transform: scale(1.05);
        }
      `}</style>
    </section>
  );
};

export default Hero;
