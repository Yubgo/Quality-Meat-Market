import { useEffect, useRef, useState } from 'react';

const standards = [
  {
    image: '/images/butcher-kitchen.jpg',
    title: 'Clean protein you can trust',
    description: 'No antibiotics or added hormones, ever.',
  },
  {
    image: '/images/pasture-raised-cows.jpg',
    title: 'Practices that prioritize animals',
    description: 'Humanely-raised meat—without compromise.',
  },
  {
    image: '/images/sustainable-fishing.jpg',
    title: 'Methods that protect marine health',
    description: '100% sustainably harvested seafood.',
  },
  {
    image: '/images/happy-customers-review.jpg',
    title: 'Meat that raises the bar',
    description: 'Free of over 200 banned ingredients.',
  },
];

const Standards = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsVisible(entry.isIntersecting);
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!isVisible) return;

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % standards.length);
    }, 4000);

    return () => clearInterval(interval);
  }, [isVisible]);

  return (
    <section ref={sectionRef} className="py-20 bg-gradient-to-b from-green-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl md:text-5xl font-bold text-center text-gray-800 mb-16">
          Superior standards, no exceptions
        </h2>

        {/* Desktop Carousel */}
        <div className="hidden md:block">
          <div className="relative overflow-hidden rounded-2xl shadow-2xl" style={{ height: '500px' }}>
            {standards.map((standard, index) => (
              <div
                key={index}
                className={`absolute inset-0 transition-all duration-1000 ${
                  index === currentIndex
                    ? 'opacity-100 translate-x-0'
                    : index < currentIndex
                    ? 'opacity-0 -translate-x-full'
                    : 'opacity-0 translate-x-full'
                }`}
              >
                <div className="relative h-full overflow-hidden">
                  {/* Background Image */}
                  <img
                    src={standard.image}
                    alt={standard.title}
                    className="absolute inset-0 w-full h-full object-cover"
                  />
                  {/* Dark Overlay for better text readability */}
                  <div className="absolute inset-0 bg-black/50"></div>
                  {/* Content */}
                  <div className="relative h-full flex items-center justify-center p-12">
                    <div className="text-center text-white max-w-3xl">
                      <p className="text-green-300 text-xl mb-4 font-semibold">{standard.title}</p>
                      <h3 className="text-5xl font-bold drop-shadow-lg">{standard.description}</h3>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Carousel Indicators */}
          <div className="flex justify-center mt-8 space-x-3">
            {standards.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`w-3 h-3 rounded-full transition-all duration-300 ${
                  index === currentIndex ? 'bg-green-600 w-8' : 'bg-gray-300'
                }`}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
        </div>

        {/* Mobile Grid */}
        <div className="grid md:hidden grid-cols-1 gap-6">
          {standards.map((standard, index) => (
            <div
              key={index}
              className="relative rounded-xl shadow-lg overflow-hidden"
              style={{ height: '300px' }}
            >
              {/* Background Image */}
              <img
                src={standard.image}
                alt={standard.title}
                className="absolute inset-0 w-full h-full object-cover"
              />
              {/* Dark Overlay */}
              <div className="absolute inset-0 bg-black/50"></div>
              {/* Content */}
              <div className="relative h-full flex items-center justify-center p-8 text-center text-white">
                <div>
                  <p className="text-green-300 mb-2 font-semibold">{standard.title}</p>
                  <h3 className="text-2xl font-bold drop-shadow-lg">{standard.description}</h3>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Standards;
