const reasons = [
  {
    icon: '💰',
    title: 'Hard-to-beat meat prices',
    description: 'Up to 15% savings on premium cuts vs. grocery stores—plus zero lines.',
    badge: 'Best Prices',
  },
  {
    icon: '🎁',
    title: 'Loyalty that pays off',
    description: 'Get 2% back on every order in rewards points, redeemable for savings on future boxes.',
    badge: 'Sizzle Perks',
  },
  {
    icon: '🔥',
    title: 'Exclusive weekly deals',
    description: 'Members get access to perks like "free-for-life" offers on select meats.',
    badge: 'Weekly Deals',
  },
];

const WhyChooseUs = () => {
  return (
    <section id="about" className="py-20 bg-gradient-to-b from-white to-green-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-4">
          <p className="text-green-600 font-semibold text-lg">The value of a ButcherBox Membership</p>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mt-2 mb-16">
            Why 400,000+ members choose us
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-20">
          {reasons.map((reason, index) => (
            <div
              key={index}
              className="reason-card bg-white rounded-xl shadow-lg p-8 hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-3"
              style={{ animationDelay: `${index * 0.15}s` }}
            >
              <div className="inline-block px-4 py-1 bg-green-100 text-green-700 rounded-full text-sm font-semibold mb-4">
                {reason.badge}
              </div>
              <div className="text-6xl mb-4">{reason.icon}</div>
              <h3 className="text-2xl font-bold text-gray-800 mb-3">{reason.title}</h3>
              <p className="text-gray-600 leading-relaxed">{reason.description}</p>
            </div>
          ))}
        </div>

        {/* Comparison Table */}
        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
          <div className="bg-gradient-to-r from-green-600 to-green-700 text-white py-6 px-8">
            <h3 className="text-3xl font-bold text-center">ButcherBox vs Others</h3>
            <p className="text-center text-green-100 mt-2">How we compare with other meat delivery services</p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Feature</th>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-green-700 bg-green-50">
                    ButcherBox
                  </th>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-gray-700">Good Chop</th>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-gray-700">Good Ranchers</th>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-gray-700">Omaha Steaks</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                <tr className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 text-sm font-medium text-gray-800">Pricing</td>
                  <td className="px-6 py-4 text-center text-sm text-green-700 font-semibold bg-green-50">
                    $8.52-$15.23/lb
                  </td>
                  <td className="px-6 py-4 text-center text-sm text-gray-600">$10.64-$18.43/lb</td>
                  <td className="px-6 py-4 text-center text-sm text-gray-600">$14.53-$16.98/lb</td>
                  <td className="px-6 py-4 text-center text-sm text-gray-600">$20.52/lb</td>
                </tr>
                <tr className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 text-sm font-medium text-gray-800">Free Shipping</td>
                  <td className="px-6 py-4 text-center bg-green-50">
                    <span className="text-green-600 text-2xl">✓</span>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className="text-red-600 text-2xl">✗</span>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className="text-green-600 text-2xl">✓</span>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className="text-red-600 text-2xl">✗</span>
                  </td>
                </tr>
                <tr className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 text-sm font-medium text-gray-800">No Antibiotics</td>
                  <td className="px-6 py-4 text-center bg-green-50">
                    <span className="text-green-600 text-2xl">✓</span>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className="text-green-600 text-2xl">✓</span>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className="text-green-600 text-2xl">✓</span>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className="text-gray-400 text-sm">Unknown</span>
                  </td>
                </tr>
                <tr className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 text-sm font-medium text-gray-800">Sustainability</td>
                  <td className="px-6 py-4 text-center bg-green-50">
                    <span className="text-green-600 text-2xl">✓</span>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className="text-red-600 text-2xl">✗</span>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className="text-red-600 text-2xl">✗</span>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className="text-red-600 text-2xl">✗</span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes cardFadeIn {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .reason-card {
          animation: cardFadeIn 0.8s ease-out forwards;
          opacity: 0;
        }

        .reason-card:hover {
          box-shadow: 0 25px 50px -12px rgba(34, 197, 94, 0.25);
        }
      `}</style>
    </section>
  );
};

export default WhyChooseUs;
